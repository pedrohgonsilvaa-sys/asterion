# Relatório de consolidação candidata v1.8.0

Estado: CANDIDATO NÃO CANÔNICO. A v1.8.0 deriva documentalmente da v1.7.0. A v1.7.0 e seu ZIP de origem foram preservados sem alteração.

## Decisões incorporadas em 2026-10-24

- Game Design aprovou os atributos individuais dos 66 novos equipamentos regionais e dos 34 Equipamentos de Origem exatamente como registrados nas matrizes da Fase 2D-C v1.0.0. Os campos originais, IDs, slots, categorias, formas, mãos, vínculos e restrições foram preservados; acrescentou-se apenas o estado/fonte/data da aprovação nas matrizes evidenciais.
- Os 12 Cajados/Bastões regionais mantêm compatibility_tags=[] explicitamente. A forma da arma não concede tags.
- Os 24 pares Torso/Mítico foram aprovados como inelegíveis pela regra estrutural: quatro secundários requeridos, capacidade do pool de Torso igual a três.

## Estados mantidos

- Os 63 pares com evidência local favorável continuam com essa evidência registrada, sem validação de release e sem promoção automática a elegíveis finais.
- Os outros 633 pares permanecem pendentes de evidência ou decisão. A elegibilidade final continua sem conclusão para os 696 pares que não foram aprovados como exclusões.
- Os 226 template IDs seguem candidatos; nenhum foi verificado em snapshot de release nesta revisão. As receitas, outputs, recompensas de Campanha e divergência de autoridade TDO continuam sob seus gates anteriores.
- GO documental. NO-GO para publicação canônica, importação, migração, ativação, integração operacional, merge ou deploy.

## Preservação

O pacote v1.7.0 de entrada permanece intacto. Esta revisão não modifica GDD, fontes regionais, SOURCE_AUTHORITY.md, código, bancos ou dados persistidos.
