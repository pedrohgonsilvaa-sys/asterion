# Diff documental — pacote candidato v1.6.0 → v1.7.0

**Estado:** candidato, não canônico e não publicado. **Registro decisório:** Adendo de Homologações de Game Design v1.0.0, 2026-10-24.

## Incorporado

- Dez classificações especiais registradas como aprovadas por Game Design. Os três registros anteriores foram reafirmados; as outras sete categorias receberam aprovação expressa no adendo. As categorias coincidem com os valores propostos na v1.6.0.
- Treinamento v0.4 aprovado: matriz detalha as 15 Proficiências, classes naturais, níveis, Provações P6/P12/P18/P24 e custos por nova Proficiência.
- Núcleos de armadura v0.7 aprovados: 16 vetores e quatro totais conferidos.
- Escudo aprovado: HP 25 / ATQ 0 / DEF 10 / AGI 0 / Bloqueio inerente 0, Secundária e Proficiência Escudo.
- Pesos de Saque v0.4 aprovados em 144 linhas; elegibilidade template x raridade continua pendente em 720 combinações.
- Overlay de recompensas ganhou campos de namespace explícitos. Os valores dos 24 vínculos permaneceram iguais.

## Preservado

- Os 226 template IDs e seus campos de proveniência são idênticos à v1.6.0. Nenhum ID foi validado em release.
- O pacote v1.6.0 completo e seu ZIP foram preservados em inputs/v1.6.0.
- A reconciliação local de 24 recompensas e a separação entre mission_id, RewardEvent.source_id, EquipmentItem.source_key e equipment_template_id foram mantidas.
- Terras do Ocaso v1.0.17 permanece como baseline-alvo; v1.0.16 continua como proveniência. A divergência entre índices raiz e worktree permanece explícita, sem sincronização.
- Atributos individuais dos 66 itens regionais e 34 itens de Origem, receitas, vínculos de release e elegibilidade individual não foram aprovados por inferência.

## Limite

As aprovações são de Game Design e aguardam formalização canônica. Não houve alteração de GDD, fontes regionais, SOURCE_AUTHORITY.md, código, banco, runtime ou catálogo de release.