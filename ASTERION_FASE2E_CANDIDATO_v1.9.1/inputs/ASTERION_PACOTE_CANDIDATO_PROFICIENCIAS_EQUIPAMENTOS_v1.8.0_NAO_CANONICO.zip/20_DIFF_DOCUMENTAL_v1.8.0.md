# Diff documental — v1.7.0 para v1.8.0

Data: 2026-10-24. A v1.8.0 é candidata, não canônica, e preserva a v1.7.0 de entrada.

## Alterações nesta revisão

1. Acrescentada aprovação de Game Design aos valores das 66 linhas regionais e 34 linhas de Origem, em 18_MATRIZ_ATRIBUTOS_REGIONAIS_66_APROVADA_v1.8.0.csv e 19_MATRIZ_ATRIBUTOS_ORIGEM_34_APROVADA_v1.8.0.csv. Os valores, IDs, slots, formas, mãos, vínculos e demais colunas recebidas permanecem inalterados.
2. Ledger de 226 IDs ganhou colunas de aprovação individual para exatamente esses 100 IDs; os campos de identidade/release continuam inalterados e 0/226 permanecem verificados em release.
3. Decisão explícita registrada para as 12 armas regionais: seis Cajados e seis Bastões têm compatibility_tags=[]; nenhuma tag decorre da forma.
4. Matriz template×raridade registra 24 pares Torso/Mítico como inelegíveis aprovados. 63 pares mantêm evidência local favorável e não são promovidos a elegíveis finais; 633 continuam pendentes. A disponibilidade em release permanece desconhecida.
5. Matriz de decisões, matriz de pendências, GO/NO-GO, relatório, README e manifesto foram versionados para v1.8.0. SHA256SUMS foi recalculado para o conteúdo desta revisão.

## Não alterado / ainda pendente

- Os 226 IDs e seus namespaces; nenhuma identidade foi verificada em release.
- Os 198 vínculos/receitas novos e as recompensas de Campanha; sem homologação adicional.
- Valores, categorias e decisões anteriores aprovados na v1.7.0.
- Terras do Ocaso v1.0.17 como alvo candidato, v1.0.16 como proveniência histórica e a divergência com SOURCE_AUTHORITY.md raiz.
- Fontes canônicas, GDD, SOURCE_AUTHORITY.md, código, bancos, dados persistidos e estado da feature flag.

## Gates

GO documental para revisão Game Design. NO-GO para publicação canônica, importação de catálogo, acesso a release, migração, integração operacional, ativação da feature flag, merge e deploy.
