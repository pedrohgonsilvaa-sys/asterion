# Adendo candidato — Weapon Metadata v1.4.0

Estado: candidato não canônico. Propõe alteração pontual do Contrato Global de Weapon Metadata v1.0.0 FINAL; não altera a fonte vigente.

1. `weapon_form` descreve a forma e mapeia para Proficiência de equipagem. A forma não concede tag de Arte.
2. `compatibility_tags: []` presente significa conjunto explicitamente vazio: não concede compatibilidade por tag e não é curinga. Campo ausente/null é metadata incompleta e não equivale a `[]`.
3. Não inferir compatibilidade melee. Requisitos das Artes e tags aceitas devem permanecer explícitos.
4. Cajado → Cajado; Bastão → Bastão. Escudo não é arma, não recebe `weapon_type_id`, usa Secundária/Proficiência Escudo e é bloqueado por Principal 2H.

## Correção de Confins para a próxima revisão

Substituir as declarações das seções 9 e 14.3 de que não há Fonte Regional FINAL de Confins. `SOURCE_AUTHORITY.md` raiz registra Confins do Véu v1.0.0 FINAL, e a seção 19.2 dessa Fonte declara metadata para cinco armas regionais Grau VI. Apontar para essa autoridade sem estender o mapeamento a itens não publicados.

O arquivo `09_WEAPON_METADATA_20_v1.4.0.csv` conserva os 20 candidatos e separa lista vazia explícita de metadata ausente.
