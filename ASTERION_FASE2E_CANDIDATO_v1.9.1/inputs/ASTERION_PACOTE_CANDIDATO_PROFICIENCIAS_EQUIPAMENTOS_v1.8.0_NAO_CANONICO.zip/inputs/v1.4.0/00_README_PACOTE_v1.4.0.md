# Pacote candidato v1.4.0 — Proficiência com Equipamentos

Dados de fechamento **não canônicos e não implementados**. `01_MANIFESTO_CATALOGO_DADOS_v1.4.0_CANDIDATO.json` é o manifesto estruturado; CSVs são visões de implementação/revisão futura.

- `02`/`13`/`17`: ledger de template IDs e evidência da busca literal de template/recipe IDs no corpus.
- `03`/`04`: receitas candidatas dos 66 novos itens e custos por item_level.
- `05`/`06`: links candidate para receitas/output e referências de recompensa de Campanha.
- `07`/`08`: elegibilidade normal de Saque por template/raridade e normalização de grupo.
- `09`–`12`: Weapon Metadata, Origem, Escudos e IDs de material.
- `14`–`16`: pendências verificáveis e adendos candidatos.

O construtor `_build_candidate_package.py` reproduz os arquivos a partir do pacote v1.3.0 e corpus local. É ferramenta de geração de artefatos de balanceamento; não é código do jogo.

Resultado: 192 templates regionais + 34 de Origem = 226 IDs únicos no namespace `equipment_template_id`. Nomes de receita, output, armas, missões e chaves de instância não são intercambiáveis. Nenhuma chance global de equipamento foi alterada; nenhuma receita Lendária/Mítica foi proposta.
