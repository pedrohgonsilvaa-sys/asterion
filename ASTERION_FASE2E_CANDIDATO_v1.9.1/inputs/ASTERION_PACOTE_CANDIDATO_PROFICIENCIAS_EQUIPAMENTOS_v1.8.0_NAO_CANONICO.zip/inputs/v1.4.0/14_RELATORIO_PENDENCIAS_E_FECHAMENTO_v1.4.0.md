# Fechamento técnico de dados — Proficiência com Equipamentos v1.4.0

**Estado:** candidato não canônico; sem publicação ou implementação.  
**Escopo:** identificação, ligações de receita/Saque, Weapon Metadata e preservação dos Equipamentos de Origem. Os núcleos numéricos permanecem congelados; não há nova auditoria de balanceamento.

## Dados fechados nesta revisão

- Catálogo regional: 192 registros — 46 IDs existentes no registro v1.3.0, 80 IDs reconciliados candidatos e 66 templates novos candidatos. Os 226 `template_id` regionais + Origem são únicos entre si; receitas, armas e instâncias têm namespaces separados.
- Os 46 IDs existentes tiveram ocorrência literal no corpus consultado. Isso confirma presença nos arquivos locais, não no snapshot de release.
- Os 80 reconciliados e 66 novos não tiveram ocorrência literal no corpus consultado; permanecem candidatos até conferência de release.
- Crafting: 198 receitas propostas Comum/Raro/Épico para os 66 novos templates; cada linha tem `recipe_id`, `output_id = template_id`, Ofício, portões, materiais por `EconomySW`, custos em Coroas e níveis materializados. Não foram criadas receitas Lendárias ou Míticas.
- Nos 160 vínculos dos templates reconciliados, os 160 `recipe_id` constam no registry local (`RECIPE_BY_ID`) e cada `output_id` runtime está `None`; o manifesto mapeia o output candidato ao `template_id` correspondente, sem reescrever o valor atual. Os novos 198 `recipe_id` são candidatos e não aparecem no corpus local.
- Os 1.980 pares receita/nível tiveram `item_level`, materiais e Coroas conferidos pelas funções de economia de Ofícios vigentes (`recipe_item_level`, `recipe_materials`, `recipe_crown_cost`).
- Economia: proporção 70/30 aplicada sobre o total após SW e arredondada uma vez; materiais e custos calculados com GDD §49.11. `EconomySW` permanece separado de `SlotWeight`.
- Exemplo reproduzível no Grau I: Capuz do Véu de Brasa Comum (`SW=1`, item_level 1) usa 5 básicos, 4 Couros Escoriados + 1 Erva Cinzenta e custa 30 Coroas (`C(1)=120`; `round_10(120×1×0,25)`). Cajado do Caminhante Raro (`SW=3`, item_level 1) usa 24 básicos (17 Ferro de Fuligem + 7 Resíduos), 12 Fragmentos e custa 130 Coroas (`round_10(120×3×0,35)`).
- Saque: 144 templates normais candidatos, avaliados em 720 combinações template/raridade; 696 permanecem elegíveis depois dos filtros. Pesos brutos v0.4 normalizam depois dos filtros. Os seis pools Torso/Mítico são removidos por capacidade 3 < 4; os demais grupos permanecem. Como os grupos são uniformes, os novos templates representam 30% do roll para Comum–Lendário e 28,5714% para Mítico (5 grupos com 40% novo entre 7 ativos). A chance global de Equipamento não muda.
- Recompensas: 24 associações de Campanha mantêm P# como referência editorial, sem promovê-lo a `mission_id`.
- Weapon Metadata: 20 candidatos; forma dá apenas Proficiência de equipagem. `compatibility_tags=[]` é lista explicitamente vazia e distinta de metadata ausente. Escudo é item não-arma de Secundária, Proficiência Escudo e incompatível com Principal 2H.
- Origem: 34 templates preservados e Acessório/Artefato vazios. Concessão apenas na criação, sem retorno econômico. A regra candidata bloqueia a remoção que apague a última configuração funcional legal.

## Pendências efetivas e verificáveis

1. **IDs/instâncias no release:** o corpus local consultado tem 13 raízes (código, testes, migrations, docs, índice, GDD, contrato e seis finais regionais); não havia conexão/snapshot do banco de release. Conferir os 80 reconciliados, 66 novos, 34 Origem e referências de instâncias no snapshot antes da publicação. Os 46 encontrados localmente também precisam da comparação de release.
2. **24 recompensas de Campanha:** os registros usam P3/P6; não trazem `mission_id`/`reward_id` estável. Esses campos estão vazios de propósito; preencher pela fonte de missão do release.
3. **36 material IDs:** todos foram observados no registry de Ofícios local. Confirmar IDs e disponibilidade no catálogo ativo do release.
4. **198 novos `recipe_id`:** seguem o padrão de família/Ofício observado, são únicos no conjunto candidato e não têm ocorrência literal no corpus local consultado. São IDs propostos; verificar unicidade no registry de release antes de registrar.
5. **Weapon Metadata:** a extensão deve aceitar `compatibility_tags=[]` como dado explícito sem aceitar metadata ausente como equivalente. A próxima revisão do contrato deve corrigir as declarações nas seções 9 e 14.3: `SOURCE_AUTHORITY.md` registra Confins do Véu v1.0.0 FINAL.
6. **Proteção do kit de Origem:** o guardião pós-descarte está especificado como regra candidata, mas precisa de validação no fluxo transacional e nos inventários legados antes da publicação.

## Limites da conferência

Código lido somente para confirmar fórmulas e formato local dos links. Nenhum código, teste, banco, GDD, contrato canônico, fonte regional ou `SOURCE_AUTHORITY.md` foi alterado. Nenhuma linha de instância do banco de release foi consultada.
