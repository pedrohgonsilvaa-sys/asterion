# Adendo candidato — concessão e proteção de Equipamentos de Origem v1.4.0

Preserva os 34 templates e valores congelados do pacote anterior. Acessório e Artefato permanecem vazios. Estado não canônico.

- Conceder somente na criação, como transação atômica/idempotente por personagem + concessão de Origem. Retry não duplica; troca de Caminho, Legado e recuperação normal não concedem novamente.
- Os itens não podem ser vendidos, trocados, listados, desmontados, reembolsados ou convertidos em cashback.
- Antes de descartar/destruir qualquer peça, simular o inventário pós-operação. Exigir ao menos uma configuração completa legal: Principal e uma peça em Cabeça, Torso, Mãos e Pés. Validar Proficiências, nível, slot/mãos, bloqueio da Secundária por Principal 2H e tags exigidas pelas Artes Ativas. Secundária pode ficar vazia com arma 2H. Rejeitar a remoção se não existir configuração funcional após a ação.
- A validação ocorre na mesma transação da remoção. Recovery só conclui a concessão original incompleta usando o recibo/chave idempotente original; não cria outro kit, não restaura item alterado e não concede valor econômico.

O guardião de perda de configuração funcional é uma regra candidata e requer validação do fluxo transacional antes da publicação.
