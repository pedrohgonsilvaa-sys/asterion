# Asterion — Proposta de Contrato de Núcleos de Armadura v0.7.0

**Estado:** solução técnica para revisão de Game Design; não canônica e não homologada.  
**Data:** 2026-10-22  
**Escopo:** explicar o resultado 8/256 da auditoria v0.6.0 e propor um contrato determinístico de núcleo para Cabeça, Torso, Mãos e Pés nas categorias Vestes, Leve, Média e Pesada.

## Resumo executivo

A causa das 248 combinações rejeitadas é o whitelist atual de **atributos-base do núcleo por slot**, usado pelo validador de equipamento. Esse whitelist reflete o único núcleo genérico publicado hoje para cada slot no GDD: Cabeça e Torso aceitam HP/DEF; Mãos, ATQ/DEF; Pés, HP/AGI. A matriz v0.3.0 preserva esses valores em Média e distribui outros atributos-base entre as categorias novas.

A auditoria v0.6.0 contou corretamente as combinações aceitas pelo whitelist atual, mas sua expressão “pools de núcleo incompatíveis” pode ser confundida com os pools de **secundários**. São regras separadas. O próprio validador distingue `CORE_POOLS` de `SECONDARY_POOLS`; o GDD também separa “núcleo/base” de budget e seleção de secundários. Não encontrei incompatibilidade que justifique alterar pools de secundários, Runas ou Encantamentos.

**Solução recomendada:** manter intactos os 16 vetores numéricos da matriz v0.3.0 e definir o núcleo-base do item pela chave **(slot corporal, categoria)**. O contrato restringe cada par a exatamente o vetor candidato daquela linha. Com isso, as 256 distribuições entre quatro slots são estruturalmente válidas, sem liberar combinações arbitrárias de atributos. A Proficiência exigida é a da categoria de cada peça; a legalidade do loadout de um personagem continua condicionada às Proficiências que ele conhece.

Esta é uma proposta de regra global nova. O GDD atual ainda não publica categorias de armadura nem estes núcleos.

## Fontes e nível de autoridade

**Fatos vigentes:** [SOURCE_AUTHORITY.md](../SOURCE_AUTHORITY.md) seleciona o [GDD Estrutural v1.6.0](../ASTERION_GDD_Estrutural_v1.6.0_Fonte_Mestra.md) como autoridade global. Relevantes: §§24.2, 24.5–24.6, 49.0 e 49.8. O GDD declara que as categorias globais de armadura ainda não existem (§24.2); publica núcleos Comum +0 por slot e os pools de secundários/componentes separadamente (§49.8); e manda o materializador calcular núcleo/base separadamente de budget e magnitudes secundárias (§24.6).

**Propostas consideradas:** matriz de proteção da nota v0.3.0 (no ZIP anexado), treinamento e saque v0.4.0 (ZIP anexado), manifesto não canônico v0.5.0 e auditoria numérica não canônica v0.6.0. As categorias e os valores continuam propostas. Os limites de Proficiência citados abaixo reproduzem v0.4.0 como hipótese de trabalho, não como regra vigente.

**Evidência técnica de implementação, sem autoridade canônica:** `src/asterion/domain/equipment_stats.py` mantém `CORE_POOLS` e `SECONDARY_POOLS` como estruturas distintas. Em `item_snapshot_from_persisted`, valida os nomes do mapa `core` contra `CORE_POOLS[slot]` e, separadamente, cada nome de `secondaries` contra `SECONDARY_POOLS[slot]`. Essa observação explica a contagem do código atual; não substitui nem amplia o GDD.

## 1. Causa exata do 8/256

Os quatro pools de núcleo que o validador atual aceita são:

| Slot | Atributos de núcleo aceitos atualmente |
|---|---|
| Cabeça | HP, DEF |
| Torso | HP, DEF |
| Mãos | ATQ, DEF |
| Pés | HP, AGI |

Comparei os atributos **não nulos** de cada vetor candidato v0.3.0 com esse whitelist. O estado “aceito hoje” na matriz assume que o mapa de núcleo contém somente as chaves não zero: o validador atual verifica todo nome presente, mesmo que seu valor seja zero. A elegibilidade é independente em cada slot:

| Slot | Categorias aceitas hoje | Rejeições no whitelist atual | Contagem aceita |
|---|---|---|---:|
| Cabeça | Média, Pesada | Vestes inclui ATQ; Leve inclui AGI | 2/4 |
| Torso | Média, Pesada | Vestes inclui ATQ; Leve inclui AGI | 2/4 |
| Mãos | Vestes, Média | Leve inclui AGI; Pesada inclui HP | 2/4 |
| Pés | Média | Vestes inclui ATQ; Leve e Pesada incluem DEF | 1/4 |

Como uma distribuição contém uma escolha para cada slot, o produto é **2 × 2 × 2 × 1 = 8** combinações aceitas. As outras **248** falham em pelo menos um slot sob aquele whitelist.

Isso não demonstra que os valores-base propostos violam pools de secundários. O erro é comparar novos **atributos-base de núcleo** com uma lista de atributos-base permitidos pelo validador atual, que foi criada para o catálogo de núcleo fixo existente. O GDD não declara que o atributo de núcleo deva também aparecer no pool de secundários do mesmo slot.

## 2. Núcleo, secundários e componentes

| Camada | Significado no contrato proposto | O que determina |
|---|---|---|
| Núcleo/base | Bônus plano determinístico do item, aqui definido por categoria e slot | HP, ATQ, DEF e AGI da linha da matriz |
| Secundários | Rolls distintos materializados conforme raridade e pool do slot | Identidade e magnitude segundo §§24.6 e 49.8 |
| Runa/Encantamento | Componentes instalados, com elegibilidade e potência próprias por slot | Efeito do componente, sem mudar identidade do núcleo ou dos secundários |

Os números da matriz v0.3.0 são vetores de **núcleo**, não rolls secundários. Um núcleo Vestes de Cabeça pode conter ATQ mesmo que ATQ não apareça no pool de secundários ou componentes de Cabeça. Não se deve convertê-lo em secundário: isso consumiria espaço/budget de raridade, faria o valor variar com raridade e tornaria o resultado diferente da proposta.

## 3. Contrato recomendado de núcleo por slot e categoria

### Regra de dados proposta

1. Cada peça corporal recebe uma categoria explícita: `Vestes`, `Leve`, `Média` ou `Pesada`.
2. O seu núcleo é exatamente o vetor da linha correspondente a **categoria × slot** na tabela abaixo. A categoria não sorteia nem troca atributos dentro do vetor.
3. A representação materializada omite atributos com valor zero; assim, o mapa de núcleo contém apenas os atributos presentes no vetor. Valores negativos, atributos fora de HP/ATQ/DEF/AGI ou núcleos alternativos sem aprovação não são permitidos.
4. O núcleo de item continua seguindo o GDD: valor de referência Nv.60 multiplicado por `G(item_level)`, com `round_half_up` por peça; Aprimoramento multiplica núcleo e secundários pelos fatores totais oficiais. Classe, Caminho, raridade e seed não rerrolam nem redistribuem os pontos do núcleo.
5. Raridade continua controlando quantidade/budget de secundários conforme GDD §49.8. O requisito de nível, materialização, bind, Legado e componentes permanecem sob as regras vigentes do GDD.
6. O campo de Proficiência exigida para a peça é a Proficiência da própria categoria. Não há requisito de conjunto completo, penalidade por mistura, bônus de conjunto nem restrição adicional por Classe/Caminho nesta proposta.
7. A validação do núcleo consulta o par categoria×slot. Os slots que não são proteção corporal conservam os núcleos vigentes do GDD §49.8.

A tabela registra cada valor Nv.60 Comum +0, idêntico à matriz v0.3.0:

| Categoria | Slot | HP | ATQ | DEF | AGI | Atributos-base presentes |
|---|---|---:|---:|---:|---:|---|
| Vestes | Cabeça | 35 | 2 | 5 | 0 | HP, ATQ, DEF |
| Vestes | Torso | 85 | 3 | 10 | 0 | HP, ATQ, DEF |
| Vestes | Mãos | 0 | 11 | 4 | 0 | ATQ, DEF |
| Vestes | Pés | 38 | 3 | 0 | 8 | HP, ATQ, AGI |
| Leve | Cabeça | 40 | 0 | 5 | 3 | HP, DEF, AGI |
| Leve | Torso | 80 | 0 | 8 | 10 | HP, DEF, AGI |
| Leve | Mãos | 0 | 11 | 0 | 4 | ATQ, AGI |
| Leve | Pés | 53 | 0 | 4 | 6 | HP, DEF, AGI |
| Média | Cabeça | 45 | 0 | 6 | 0 | HP, DEF |
| Média | Torso | 95 | 0 | 12 | 0 | HP, DEF |
| Média | Mãos | 0 | 10 | 5 | 0 | ATQ, DEF |
| Média | Pés | 60 | 0 | 0 | 8 | HP, AGI |
| Pesada | Cabeça | 40 | 0 | 7 | 0 | HP, DEF |
| Pesada | Torso | 91 | 0 | 13 | 0 | HP, DEF |
| Pesada | Mãos | 26 | 3 | 10 | 0 | HP, ATQ, DEF |
| Pesada | Pés | 63 | 0 | 3 | 3 | HP, DEF, AGI |

Totais do núcleo das quatro peças, para conferência contra a matriz:

| Categoria | HP | ATQ | DEF | AGI |
|---|---:|---:|---:|---:|
| Vestes | 158 | 19 | 19 | 8 |
| Leve | 173 | 11 | 17 | 23 |
| Média | 200 | 10 | 23 | 8 |
| Pesada | 220 | 3 | 33 | 3 |

Média coincide numericamente com os quatro núcleos corporais do GDD §49.8. Isso serve como âncora de compatibilidade, mas **não torna “Média” canônica**.

### Pools preservados sem alterações

A matriz candidata não cria incompatibilidade com os pools abaixo porque os valores novos são núcleo/base. Recomendo manter exatamente os pools do GDD §49.8:

| Slot | Secundários do equipamento | Runas e Encantamentos |
|---|---|---|
| Cabeça | HP, DEF, PER, CRIT | HP, DEF, PER, CRIT |
| Torso | HP, DEF, Bloqueio | HP, DEF, Bloqueio |
| Mãos | ATQ, AGI, PER, CRIT | ATQ, DEF, AGI, PER, CRIT |
| Pés | HP, DEF, AGI, Esquiva | HP, DEF, AGI, Esquiva |

A diferença existente para Mãos entre secundários e componentes permanece como está no GDD. Sem mudança nos pools, raridade Mítica de Torso continua inelegível enquanto houver só três identidades de secundário e forem exigidos quatro distintos; esta proposta não altera essa regra.

## 4. Proficiências e mistura livre

A categoria da peça também determina a Proficiência que o personagem deve conhecer. Sob a matriz não canônica v0.4.0:

| Proficiência da armadura | Natural em v0.4.0 | Treinamento proposto se faltar |
|---|---|---|
| Vestes | Tecelão, Oráculo, Luminar | Etapa I: Nv.10 + P6; 250 Coroas |
| Leve | Errante, Vigia, Tecelão, Oráculo | Etapa I: Nv.10 + P6; 250 Coroas |
| Média | Sentinela, Errante, Vigia, Luminar | Etapa II: Nv.20 + P12; 400 Coroas |
| Pesada | Sentinela | Etapa II: Nv.20 + P12; 400 Coroas |

O layout estrutural não confere as Proficiências ao personagem. O loadout real só é equipável quando o personagem conhece a Proficiência de cada categoria usada; repetição da mesma categoria em vários slots exige uma única Proficiência conhecida.

A distribuição das 256 combinações por número de Proficiências distintas necessárias é:

| Proficiências distintas no layout | Combinações |
|---:|---:|
| 1 | 4 |
| 2 | 84 |
| 3 | 144 |
| 4 | 24 |

Como ilustração dos gates v0.4.0, cada Classe tem duas categorias naturais, equivalentes a 16 layouts corporais possíveis ao criar o personagem. Após aprender todas as categorias que lhe faltam, qualquer Classe pode usar os 256 layouts. O CSV informa, por combinação, as categorias exigidas e a etapa mais tardia da proposta v0.4.0 caso todas as Proficiências necessárias estivessem faltando. Requisitos naturais reduzem essa etapa por personagem.

## 5. Reavaliação das 256 combinações

As quatro escolhas são independentes: **4 × 4 × 4 × 4 = 256**. A tabela categoria×slot contém um vetor para cada uma das 16 possibilidades; portanto, todas as 256 distribuições têm núcleo definido e são estruturalmente válidas sob o contrato proposto.

| Critério | Atual | Contrato proposto |
|---|---:|---:|
| Combinações enumeradas | 256 | 256 |
| Passam pelos pools de núcleo atuais | 8 | Não aplicável ao schema de categorias |
| Núcleo definido em cada slot escolhido | 8 layouts completos passam; demais são rejeitados | 256/256 |
| Legalidade por Proficiência do personagem | Não existe no GDD vigente | Verificada por categoria exigida e Proficiências conhecidas |

Exemplo: Cabeça Vestes + Torso Pesada + Mãos Leve + Pés Média é estruturalmente válido, usa os quatro vetores publicados na proposta e exige as quatro Proficiências. Um personagem sem alguma delas não pode equipar essa combinação até conhecê-la; isso não torna o arranjo de núcleos malformado.

O [CSV completo com as 256 combinações](ASTERION_MATRIZ_256_COMBINACOES_NUCLEOS_ARMADURA_v0.7.0_NAO_CANONICA.csv) inclui os quatro vetores por layout, atributos presentes, rejeições que cada peça recebe no whitelist atual, validade atual por núcleo, Proficiências distintas requeridas e validade estrutural sob o contrato proposto. O índice da linha é apenas ordinal; não introduz IDs de item ou identidades canônicas.

## Recomendação para aprovação

Aprovar para discussão de Game Design o **modelo de lookup determinístico categoria×slot**, mantendo os vetores numéricos v0.3.0 e preservando sem mudanças os pools secundários, Runas e Encantamentos do GDD. A revisão canônica futura precisaria formalizar as quatro categorias, os 16 vetores de núcleo, a Proficiência exigida por categoria e a separação entre núcleo e secundários.

Não recomendo ampliar os pools de secundários para contornar a rejeição: isso mudaria a materialização, budget e distribuição de raridade sem necessidade. Também não recomendo liberar qualquer atributo-base em qualquer armadura; o lookup restrito conserva exatamente os valores candidatos e evita combinações não presentes na matriz.

### Fora do escopo e estado do workspace

Esta análise não classifica nem remapeia os templates existentes das seis Regiões, os 80 registros sem ID definitivo, peças de Campanha ou Receitas especiais. Não resolve receitas, loot, migração ou disponibilidade de itens. Nenhum núcleo, categoria ou Proficiência é homologado.

Foram criados somente este relatório e seu CSV em `balanceamento/`. Não alterei código, testes, banco, migrations, GDD, Fontes Regionais ou `SOURCE_AUTHORITY.md`; alterações preexistentes fora destes dois entregáveis foram preservadas.

