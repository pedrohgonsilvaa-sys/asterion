# ASTERION — ADENDO DE HOMOLOGAÇÕES DE GAME DESIGN · PROFICIÊNCIAS E EQUIPAMENTOS v1.0.0

**Estado:** DOCUMENTO CANDIDATO PARA INCORPORAÇÃO AO PACOTE v1.6.0; NÃO É FONTE CANÔNICA INSTALADA.  
**Data da decisão:** 24/10/2026.  
**Origem:** aprovações explícitas do responsável de Game Design nesta conversa, posteriores à consolidação candidata v1.6.0.  
**Baseline-alvo candidato:** Terras do Ocaso v1.0.17 (Égide do Selo por 2T); v1.0.16 preservada como proveniência histórica. O índice raiz do checkout local e o worktree podem divergir até sincronização autorizada.

## 1. Objeto e alcance

Este adendo documenta cinco frentes homologadas em Game Design: **dez classificações de equipamentos especiais; política de treinamento v0.4; núcleos de quatro categorias de armadura v0.7; núcleo de Escudo sem Bloqueio inerente; e pesos de Saque v0.4**. As decisões valem como autoridade decisória nesta conversa, mas sua instalação no GDD, fontes oficiais, package registry e runtime requer processo documental/técnico posterior e autorização própria.

**Não aprovados por este adendo:** os 226 IDs candidatos como IDs de release; os atributos individuais de 66 novos templates regionais ou 34 de Origem; receitas e seus outputs; materiais no release; recompensas por template; eligibility template × raridade; fórmulas não demonstradas; migração de personagens; importação; publicação; staging/produção; ativação da feature flag; merge/deploy.

## 2. Classificação dos dez equipamentos especiais — HOMOLOGADA

| Peça | Categoria aprovada |
|---|---|
| Véu do Bosque | Leve |
| Guarda do Berço Silente | Média |
| Peitoral do Fluxo Contido | Média |
| Guarda do Último Posto | Pesada |
| Capuz das Copas Suspensas | Vestes |
| Capuz dos Marcos Longos | Leve |
| Máscara da Salmoura | Média |
| Capuz do Vento Preso | Vestes |
| Capuz da Dupla Leitura | Leve |
| Máscara da Triagem Silenciosa | Vestes |

As três primeiras peças haviam sido decididas anteriormente e as sete últimas foram homologadas expressamente em 24/10/2026. Sua classificação não prova que os respectivos template IDs existam no registry de release.

## 3. Treinamento de Proficiências v0.4 — HOMOLOGADO

| Etapa | Condição cumulativa | Proficiências aprendíveis, se ainda ausentes | Custo por nova Proficiência |
|---|---|---|---:|
| I | Nível 10 + missão principal P6 concluída | Espada; Adaga; Bastão; Vestes; Leve | 250 Coroas |
| II | Nível 20 + missão principal P12 concluída | Maça; Cajado; Escudo; Média; Pesada | 400 Coroas |
| III | Nível 30 + missão principal P18 concluída | Machado; Arco; Besta | 550 Coroas |
| IV | Nível 40 + missão principal P24 concluída | Martelo; Lança | 700 Coroas |

**Contrato de regra:**
- Proficiências naturais da Classe são gratuitas na criação. Raça e Caminho não concedem Proficiências naturais.
- Treinar é opcional; o custo incide individualmente por Proficiência nova, não por etapa inteira. Não cobrar treinamento de Proficiência já possuída.
- O aprendizado permanece através do Legado e deve ser persistido de forma idempotente/transacional quando ligado ao runtime.
- Proficiência permite equipar a forma/categoria correspondente; por si só não acrescenta bônus de atributos nem compatibilidade de Artes.
- A política de compra e autorização deve ser aplicada por um ponto de entrada real seguro; sua existência no runtime não é presumida por esta homologação.

## 4. Núcleos de armaduras v0.7 — HOMOLOGADOS

**Base comparativa:** item de nível 60, raridade Comum, aprimoramento +0. Valores escritos como **HP / ATQ / DEF / AGI**.

| Categoria | Cabeça | Torso | Mãos | Pés | Total HP / ATQ / DEF / AGI |
|---|---|---|---|---|---|
| Vestes | 35/2/5/0 | 85/3/10/0 | 0/11/4/0 | 38/3/0/8 | 158/19/19/8 |
| Leve | 40/0/5/3 | 80/0/8/10 | 0/11/0/4 | 53/0/4/6 | 173/11/17/23 |
| Média | 45/0/6/0 | 95/0/12/0 | 0/10/5/0 | 60/0/0/8 | 200/10/23/8 |
| Pesada | 40/0/7/0 | 91/0/13/0 | 26/3/10/0 | 63/0/3/3 | 220/3/33/3 |

A diferença de **15 AGI entre Leve (23) e Média (8)** nessa comparação foi aprovada sem ajuste. Esta matriz não cria conjunto obrigatório, bônus de set, penalidade de peso nem alteração do sistema global de atributos. A mistura de categorias permanece permitida, sujeita às Proficiências apropriadas.

## 5. Escudo — HOMOLOGADO

**Base:** nível 60, Comum, +0. **HP 25 / ATQ 0 / DEF 10 / AGI 0; Bloqueio inerente = 0**. Escudo é equipamento não-arma de slot **Secundária**, exige Proficiência **Escudo** e não é equipável quando a Principal usa arma **2H**. Esta homologação não adiciona chance global de Bloqueio ao motor de combate.

## 6. Pesos de Saque v0.4 — HOMOLOGADOS

| Grupo | Papel | Peso por template elegível |
|---|---|---:|
| Principal | Templates existentes | 30 |
| Principal | Templates novos | 20 |
| Cabeça, Torso, Mãos e Pés | Templates existentes | 30 |
| Cabeça, Torso, Mãos e Pés | Templates novos | 20 |
| Secundária | Armas existentes | 60 |
| Secundária | Escudos novos | 40 |
| Acessório e Artefato | Catálogo existente | 100 |

**Execução:** aplicar filtros antes da seleção, renormalizar os pesos entre templates elegíveis, excluir grupos vazios e preservar as chances globais de equipamento do GDD. Recompensas de Campanha e itens especiais de Receita ficam fora do Saque normal salvo inclusão expressa. Os pesos não substituem a elegibilidade específica de template e raridade, que permanece pendente de conciliação e homologação.

## 7. Estado do catálogo candidato e pendências

O pacote candidato v1.6.0 reportou **226 equipment_template_id candidatos**: 46 existentes com ocorrência no corpus local; 80 reconciliados candidatos; 66 regionais novos; 34 de Origem. O corpus local **não é snapshot de release**. Não foi demonstrada unicidade contra o registry externo nem contra instâncias persistidas.

- **Pendente:** validação de IDs no snapshot imutável autorizado de release, mantendo namespaces separados.
- **Pendente:** homologar os atributos individuais dos 66 novos regionais e dos 34 kits/itens de Origem, além dos respectivos contratos de identidade e raridade.
- **Pendente:** elegibilidade final template × raridade de Saque e exclusões por método de aquisição.
- **Pendente:** 160 receitas existentes com output_id nulo no registry local, 198 receitas candidatas, conferência de materiais e vínculos de saída.
- **Pendente:** 24 recompensas de Campanha com chaves locais reconciliadas, sem template IDs de release verificados.
- **Pendente:** formalização canônica em fonte revisada e compatibilização do GDD v1.6.0, sem sobrescrever silenciosamente contratos vigentes.
- **Pendente:** transição real de Legado e verificações de sistemas econômicos que ainda não existem no runtime (venda/troca).
- **Cobertura de testes:** validações das fases 2A–2D-A são sintéticas isoladas; skips opt-in não equivalem a execução.

## 8. Regra de incorporação documental

1. Introduzir este arquivo no pacote candidato como documento de **decisões de Game Design aprovadas, ainda não instaladas no cânone operacional**.
2. Nas matrizes de decisão, mudar apenas a situação decisória das cinco frentes para `APROVADO_GAME_DESIGN_AGUARDA_FORMALIZACAO`, conservando campos independentes como `release_verified=false`, `canonical_published=false` e `runtime_enabled=false`, segundo schema existente. Não converter automaticamente a situação dos IDs/atributos individuais.
3. Preservar os 226 IDs, suas proveniências e contagens. Não regenerar hashes da versão v1.6.0 como se ela já contivesse este adendo: gerar uma nova revisão candidata identificável, novo manifesto e novos hashes depois da incorporação efetiva.
4. Registrar explicitamente Terras do Ocaso v1.0.17 como **baseline-alvo**, sem fingir que o SOURCE_AUTHORITY.md da raiz já foi sincronizado.
5. Não modificar código, GDD, fontes regionais, índice de autoridade ou bancos nesta rodada.

## 9. GO / NO-GO

**GO:** registrar estas cinco homologações e produzir revisão exclusivamente candidata, com rastreabilidade e integridade.  
**NO-GO:** afirmar homologação de catálogo de release, importar, migrar, alterar instâncias, habilitar flag, publicar, fazer merge/deploy, promover a staging/produção ou atualizar fontes canônicas sem etapa autorizada específica.
