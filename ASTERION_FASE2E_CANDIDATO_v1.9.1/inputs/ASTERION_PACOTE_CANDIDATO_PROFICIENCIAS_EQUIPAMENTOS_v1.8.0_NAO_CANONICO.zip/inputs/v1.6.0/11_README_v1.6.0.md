# Pacote Candidato v1.6.0 — Proficiências com Equipamentos

**Status:** candidato, não canônico, não importado e não pronto para publicação.  
**Data:** 2026-10-24.

## Baseline e proveniência

Baseline-alvo desta revisão: Terras do Ocaso v1.0.17. A reconciliação de origem v1.4/v1.5 usou v1.0.16. O SOURCE_AUTHORITY.md ativo na raiz continua selecionando v1.0.16, enquanto o índice no worktree da Fase 2B seleciona v1.0.17. A divergência é registrada no manifesto com hashes. Nenhum índice foi sincronizado ou alterado.

## Artefatos

- 02_CATALOGO_STATUS_226_v1.6.0.csv: 226 template IDs/categorias candidatos; nenhum verificado em release.
- 03_CLASSIFICACOES_ESPECIAIS_10_v1.6.0.csv: três classificações decididas para este manifesto candidato e sete pendentes.
- 04_MATRIZ_DECISOES_CANDIDATO_v1.6.0.csv: matriz completa, com três classificações decididas e decisões abertas.
- 04_MATRIZ_DECISOES_PENDENTES_v1.6.0.csv: somente as decisões ainda abertas.
- 05_RECONCILIACAO_RECOMPENSAS_24_v1.5.0.csv: reconciliação v1.5 original, copiada sem transformação.
- 06_RECOMPENSAS_CAMPANHA_BASELINE_24_v1.6.0.csv: visão de baseline que preserva os campos de namespace e distingue a origem v1.5 da versão-alvo.
- 07_CONTRATO_SNAPSHOT_RELEASE_v1.6.0.md: requisitos para arquivo imutável fornecido por Release/DBA; não pede conexão direta a bancos.
- 08_DIFF_DOCUMENTAL_v1.6.0.md, 09_RELATORIO_CONSOLIDACAO_v1.6.0.md e 10_GO_NO_GO_v1.6.0.csv: alterações, limitações e decisão de prontidão.
- 12_MANIFESTO_REVISAO_v1.6.0_CANDIDATO.json: versões, proveniência e hashes.
- inputs/v1.4.0: cópias dos arquivos de dados candidatos v1.4.0; a matriz v1.2 está em inputs como histórico.

## Valores e publicação

Treinamento v0.4, núcleos corporais, Escudo, Saque v0.4, receitas e valores de Origem continuam congelados como candidatos e não homologados. Nenhum template, receita ou recompensa foi importado. Não houve acesso a banco nem alterações em código, GDD, fontes canônicas ou SOURCE_AUTHORITY.md.


