# Contrato do Snapshot Imutável de Release — candidato v1.6.0

Este contrato define somente o arquivo que Release/DBA poderá fornecer para a conciliação futura. Não solicita credenciais, conexão direta, consulta interativa nem acesso do agente a banco.

## Proveniência e integridade

O pacote deve conter manifesto JSON com release/build ID, ambiente de origem, identificador do snapshot, instante UTC da extração, versão do schema/migrations, ferramenta/versão de exportação, responsável Release/DBA, escopo, contagem de linhas e SHA-256 de cada arquivo. Release/DBA deve atestar que a exportação é imutável. Transformações ou redações precisam ser declaradas e reproduzíveis.

Entregar somente arquivos de leitura, sem credenciais, tokens, segredos, dados de autenticação ou dados pessoais. Chaves de personagem/instância podem ser pseudonimizadas de modo estável dentro do snapshot, sem alterar os identificadores de catálogo nem quebrar vínculos.

## Conjuntos separados

CSV UTF-8 ou JSON Lines UTF-8, com arquivos/tabelas distintos:

1. Registry de templates: equipment_template_id, slot, categoria, forma, Proficiência declarada, raridades, disponibilidade e estado.
2. Weapon Metadata: weapon_type_id, forma, mãos, slots elegíveis e estado de compatibility_tags, distinguindo [] presente de propriedade ausente e null.
3. Receitas e saídas: recipe_id e output_id em colunas separadas, Ofício, nível, raridade, item_level, materiais e quantidades.
4. Materiais: material_id, Grau e disponibilidade no release.
5. Instâncias/pêndencias: EquipmentItem, PendingItem, BlockedDelivery e RewardComponent com chave opaca estável e payload.template_id.
6. CraftingReceipt: recipe_id, source_key e output_payload/template_id.
7. Recompensas: Quest.quest_id, RewardEvent.source_id, RewardComponent e EquipmentItem.source_key em campos separados e com vínculos explícitos.

## Regras de conciliação

- Não colapsar namespaces. mission_id, RewardEvent.source_id, EquipmentItem.source_key, equipment_template_id, recipe_id, output_id, weapon_type_id e material_id permanecem distintos.
- Nome exibido é somente apoio; identidade requer ID e vínculo explícito.
- Incluir contagens verificáveis de cada registry, instâncias, recibos e recompensas.
- Registrar colisões, órfãos, nulls, campos ausentes e ambiguidades; não substituir silenciosamente.
- O snapshot deve corresponder exatamente ao release/build que será avaliado.

Até a recepção e validação desse artefato, existência, unicidade e vínculos persistidos não estão verificados em release. Este contrato não autoriza importação, migration, publicação, ativação ou conexão direta.
