# Diff documental — pacote candidato v1.6.0

## Entradas anteriores preservadas

- Arquivos da v1.4.0 copiados para inputs/v1.4.0 sem alterações de conteúdo; o script gerador auxiliar não foi incluído.
- CSV de recompensas v1.5.0 copiado byte a byte para 05_RECONCILIACAO_RECOMPENSAS_24_v1.5.0.csv.
- Classificações especiais v1.2.0 preservadas como histórico em inputs.
- Os 226 template IDs são idênticos ao ledger v1.4.0 e únicos somente dentro do pacote candidato. Nenhum está marcado como verificado em release.

## Matriz de decisões

A matriz completa v1.6.0 registra os três estados decididos, as sete classificações ainda abertas e os demais tópicos numéricos/contratuais pendentes. A matriz pendente separada contém apenas os itens ainda abertos.

## Sobreposições v1.6.0

1. Baseline-alvo do pacote para Terras do Ocaso: v1.0.17. A origem das reconciliações anteriores é v1.0.16. O índice ativo da raiz permanece v1.0.16; o índice no worktree da Fase 2B seleciona v1.0.17. Hashes e diferença entre checkouts constam no manifesto. Nenhum SOURCE_AUTHORITY foi escrito, copiado ou sincronizado.
2. Véu do Bosque = Leve e Guarda do Berço Silente = Média: decisões registradas para este manifesto candidato.
3. Peitoral do Fluxo Contido = Média: decisão registrada para este manifesto candidato. A linha superior da v1.4 indicava Pesada, mas o campo candidato aninhado já indicava Média. O overlay conserva os dois valores de origem e usa Média como candidato decidido.
4. As outras sete classificações especiais permanecem pendentes; as sugestões anteriores não são tratadas como aprovação.
5. A visão de Campanha v1.6 mantém mission_id/Quest.quest_id, RewardEvent.source_id, EquipmentItem.source_key e equipment_template_id separados. A origem v1.5 permanece registrada como v1.0.16; a coluna de alvo aponta v1.0.17. O diff local entre fontes regionais mostra alterações de versão/manutenção e a duração de 2T da Égide; os vínculos de campanha são herdados, sem verificação de release.
6. Treinamento v0.4, os 16 núcleos corporais, Escudo, pesos/elegibilidade de Saque v0.4, receitas, valores regionais e valores dos 34 Equipamentos de Origem permanecem candidatos congelados.

## Integridade

O manifesto inclui hashes de todos os arquivos empacotados exceto ele mesmo e SHA256SUMS.txt para evitar autorreferência. SHA256SUMS.txt cobre todos os demais arquivos, inclusive o manifesto. O hash do ZIP é calculado e reportado externamente. Nenhum código, banco, migration, fonte canônica ou SOURCE_AUTHORITY.md foi alterado.


