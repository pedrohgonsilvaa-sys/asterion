# Asterion — pacote candidato v1.8.0

Estado: NÃO CANÔNICO; GO documental; NO-GO para publicação ou integração operacional.

Derivado da v1.7.0 sem modificá-la. Incorpora aprovações explícitas de Game Design para os atributos individuais dos 66 equipamentos regionais e 34 Equipamentos de Origem, para compatibility_tags=[] nas 12 armas regionais, e para a inelegibilidade estrutural dos 24 pares Torso/Mítico.

Preserva 63 pares com evidência local favorável e 633 pares pendentes. Nenhum ID é validado em release. Ver 17_ELEGIBILIDADE_SAQUE_720_v1.8.0.csv, as matrizes 18 e 19, o relatório 20_DIFF_DOCUMENTAL_v1.8.0.md e o manifesto 12_MANIFESTO_REVISAO_v1.8.0_CANDIDATO.json.

Nenhum dado foi importado e nenhuma fonte canônica, código, banco, migração, feature flag, merge ou deploy foi alterado/executado.
